<!DOCTYPE html>
<html>
<head>
	<title>Welcome to DevOps on AWS</title>
</head>
<body>
	<h1><?php echo "Welcome to DevOps on AWS. This text was generated using PHP"; ?></h1>
</body>
</html>